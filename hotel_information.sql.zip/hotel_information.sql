-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2015 at 06:06 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel_information`
--

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE IF NOT EXISTS `hotels` (
  `hotel_id` int(50) NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `location_url` text NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`hotel_id`, `hotel_name`, `address`, `contact`, `email`, `location_url`) VALUES
(1, 'Hotel Yak & Yeti', 'Durbar Marg', '01-4240520', 'hotelyy@gmail.com', 'https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d883.097574496674!2d85.3422643!3d27.7052332!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2snp!4v1441459034078'),
(6, 'Kathmandu Guest House', 'Thamel', '01-4700632', 'ktmguesthouse@gmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.063319127325!2d85.3101365!3d27.715331199999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb18fcea19bb69%3A0xff3d1d91c61ab5d9!2sKathmandu+Guest+House!5e0!3m2!1sen!2snp!4v1441463552210'),
(7, 'Hotel Annapurna', 'Durbar Marg', '01-4221711', 'annapurna22@hotmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2497.6518985291723!2d85.3173203482339!3d27.710703230114035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb190162d2fb35%3A0x98eccd6cf32b17f9!2sHotel+Annapurna!5e0!3m2!1sen!2snp!4v1441463394834'),
(8, 'The Everest Hotel', 'Baneshor', '01-4780100', 'hoteleverest@hotmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.896730113648!2d85.3334898!3d27.6895865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb19abc9fd86b7%3A0x3eddf634ce19c051!2sThe+Everest+Hotel!5e0!3m2!1sen!2snp!4v1441463790457'),
(9, 'Shangri-La Hotel', 'Lazimpat', '01-4412999', 'shangrila@gmail.com', 'https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d11879.876359208896!2d85.32241157544246!3d27.720115178787864!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sShangri-La+Hotel!5e0!3m2!1sen!2snp!4v1441463683831'),
(10, 'Gokarna Forest Resort', 'Thali', '01-4451212', 'Gforest@hotmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3531.6827807634336!2d85.396245!3d27.727078999999996!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb190070716e75%3A0x4d248fbd20ee4dc3!2sGokarna+Forest+Resort!5e0!3m2!1sen!2snp!4v1441463184461'),
(11, 'Radisson Hotel', 'Lazimpat', '01-4411818', 'radhotel@yahoo.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3531.906512990889!2d85.3212952!3d27.720172599999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb191b0080f92b%3A0x3d08c08a7f53eace!2sRadisson+Hotel+Kathmandu!5e0!3m2!1sen!2snp!4v1441463601939'),
(12, 'Hyatt Regency Kathmandu', 'Boudha', '01-4491234', 'hyattreg@yahoo.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2969.9150807190354!2d85.3569895909522!3d27.72209800121274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb1bd88a7dce63%3A0x2f767a36da816bb5!2sHyatt+Regency+Kathmandu!5e0!3m2!1sen!2snp!4v1441463471067'),
(13, 'Dwarika Hotel', 'Battisputali', '01-4470770', 'dwarika14@gmail.com', 'https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d883.097574496674!2d85.3422643!3d27.7052332!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2snp!4v1441459034078'),
(14, 'Soaltee Crown Plaza', 'Tahachal', '01-4273999', 'crownplaza@hotmail.com', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.5364995472314!2d85.291091!3d27.70071699999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb18609488cdb7%3A0x44edd8fc9a17af63!2sCrowne+Plaza+Kathmandu-Soaltee!5e0!3m2!1sen!2snp!4v1441463741514');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL DEFAULT '',
  `customer_contact_num` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `reservation_date` date NOT NULL,
  `arrival_date` date NOT NULL,
  `departure_date` date NOT NULL,
  `room_category` int(11) NOT NULL,
  `num_rooms` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `hotel_id`, `customer_name`, `customer_contact_num`, `customer_email`, `reservation_date`, `arrival_date`, `departure_date`, `room_category`, `num_rooms`) VALUES
(6, 13, 'sudin', '9849431839', 'ranjitkarsudin@gmail.com', '2015-09-06', '2015-09-07', '2015-09-12', 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
